import GoTrueClient from "./GoTrueClient.js";
const AuthClient = GoTrueClient;
export {
  AuthClient as default
};
