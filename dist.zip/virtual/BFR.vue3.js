const overlay = "rp-BFR__overlay___69aaa4c";
const highlight = "rp-BFR__highlight___f0e835b";
const inline = "rp-BFR__inline___1757a21";
const commandCell = "rp-BFR__commandCell___967c229";
const sizeCell = "rp-BFR__sizeCell___4a6f1d3";
const tooltip = "rp-BFR__tooltip___d9f4108";
const style0 = {
  overlay,
  highlight,
  inline,
  commandCell,
  sizeCell,
  tooltip
};
export {
  commandCell,
  style0 as default,
  highlight,
  inline,
  overlay,
  sizeCell,
  tooltip
};
