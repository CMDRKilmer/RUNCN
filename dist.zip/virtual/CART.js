import xit from "./xit-registry.js";
import CART from "./CART.vue.js";
xit.add({
  command: "CART",
  name: "Shopping Cart",
  description: "Build a shopping cart, import XIT JSON, and generate ACT packages.",
  component: () => CART
});
