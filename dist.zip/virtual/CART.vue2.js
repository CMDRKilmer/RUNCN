import { vModelText, withKeys, withModifiers } from "./runtime-dom.esm-bundler.js";
import { C } from "./prun-css.js";
import _sfc_main$2 from "./ActionBar.vue.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import SectionHeader from "./SectionHeader.vue.js";
import _sfc_main$4 from "./Active.vue.js";
import SelectInput from "./SelectInput.vue.js";
import _sfc_main$3 from "./TextInput.vue.js";
import { sortMaterials } from "./sort-materials.js";
import { materialsStore } from "./materials.js";
import { showBuffer } from "./buffers.js";
import { userData } from "./user-data.js";
import { fixed02 } from "./format.js";
import { uploadJson } from "./json-file.js";
import GripCell from "./GripCell.vue.js";
import GripHeaderCell from "./GripHeaderCell.vue.js";
import { grip } from "./index17.js";
import { vDraggable as so } from "./vue-draggable-plus.js";
import { getExchangeOptions, getStationName, getWarehouseName, parseCartImport, normalizeCartName, normalizeCartItems, buildActionPackage } from "./cart-utils.js";
import { defineComponent, computed, watch, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, withDirectives, createBlock, createCommentVNode, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
const _hoisted_1 = ["onKeydown"];
const _hoisted_2 = ["onDragstart"];
const _hoisted_3 = ["checked"];
const _hoisted_4 = { key: 0 };
const _hoisted_5 = { key: 1 };
const _hoisted_6 = ["checked", "onChange"];
const _hoisted_7 = ["onUpdate:modelValue", "onChange"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CART",
  setup(__props) {
    const cart = computed(() => userData.cart);
    const search = ref("");
    const importText = ref("");
    const selectedTickers = ref([]);
    const cartDropActive = ref(false);
    const statusMessage = ref("");
    const statusError = ref(false);
    const exchangeOptions = computed(() => getExchangeOptions());
    watch(
      exchangeOptions,
      (options) => {
        if (!cart.value.exchange && options[0]) {
          cart.value.exchange = options[0].value;
        }
      },
      { immediate: true }
    );
    watch(
      () => cart.value.items.map((item) => item.ticker),
      (tickers) => {
        const allowed = new Set(tickers);
        selectedTickers.value = selectedTickers.value.filter((ticker) => allowed.has(ticker));
      },
      { immediate: true }
    );
    const filteredMaterials = computed(() => {
      const query = search.value.trim().toLowerCase();
      const materials = sortMaterials(materialsStore.all.value ?? []);
      if (!query) {
        return materials;
      }
      return materials.filter((material) => {
        const haystack = `${material.ticker} ${material.name}`.toLowerCase();
        return haystack.includes(query);
      });
    });
    const cartRows = computed(
      () => cart.value.items.map((item) => ({
        item,
        material: materialsStore.getByTicker(item.ticker)
      }))
    );
    const allSelected = computed(
      () => cart.value.items.length > 0 && cart.value.items.every((item) => selectedTickers.value.includes(item.ticker))
    );
    const hasSelection = computed(() => selectedTickers.value.length > 0);
    const totalUnits = computed(
      () => cart.value.items.reduce((sum, item) => sum + (Number.isFinite(item.amount) ? item.amount : 0), 0)
    );
    const totalWeight = computed(
      () => cartRows.value.reduce((sum, row) => sum + (row.material?.weight ?? 0) * row.item.amount, 0)
    );
    const totalVolume = computed(
      () => cartRows.value.reduce((sum, row) => sum + (row.material?.volume ?? 0) * row.item.amount, 0)
    );
    const stationName = computed(() => getStationName(cart.value.exchange) ?? "--");
    const warehouseName = computed(() => getWarehouseName(cart.value.exchange));
    function addMaterial(ticker, amount = 1) {
      const normalizedAmount = Math.max(1, Math.ceil(amount));
      const existing = cart.value.items.find((item) => item.ticker === ticker);
      if (existing) {
        existing.amount += normalizedAmount;
      } else {
        cart.value.items.push({
          ticker,
          amount: normalizedAmount
        });
      }
      setStatus(`已加入 ${ticker} x${normalizedAmount}。`);
    }
    function addFirstFilteredMaterial() {
      const first = filteredMaterials.value[0];
      if (!first) {
        setStatus("没有匹配的物品。", true);
        return;
      }
      addMaterial(first.ticker);
    }
    function onCatalogDragStart(event, ticker) {
      event.dataTransfer?.setData("text/plain", ticker);
      if (event.dataTransfer) {
        event.dataTransfer.effectAllowed = "copy";
      }
    }
    function onCartDrop(event) {
      event.preventDefault();
      cartDropActive.value = false;
      const ticker = event.dataTransfer?.getData("text/plain")?.trim().toUpperCase();
      if (!ticker) {
        return;
      }
      addMaterial(ticker);
    }
    function onCartDragLeave(event) {
      if (event.currentTarget === event.target) {
        cartDropActive.value = false;
      }
    }
    function normalizeAmount(item) {
      item.amount = Math.max(1, Math.ceil(Number(item.amount) || 1));
    }
    function isSelected(ticker) {
      return selectedTickers.value.includes(ticker);
    }
    function setSelected(ticker, selected) {
      if (selected) {
        if (!selectedTickers.value.includes(ticker)) {
          selectedTickers.value.push(ticker);
        }
        return;
      }
      selectedTickers.value = selectedTickers.value.filter((value) => value !== ticker);
    }
    function replaceCartItems(items) {
      cart.value.items.splice(0, cart.value.items.length, ...items);
    }
    function toggleSelectAll(selected) {
      selectedTickers.value = selected ? cart.value.items.map((item) => item.ticker) : [];
    }
    function onSelectAllChange(event) {
      toggleSelectAll(event.target.checked);
    }
    function onSelectChange(event, ticker) {
      setSelected(ticker, event.target.checked);
    }
    function removeItem(ticker) {
      const index = cart.value.items.findIndex((item) => item.ticker === ticker);
      if (index < 0) {
        return;
      }
      cart.value.items.splice(index, 1);
      setSelected(ticker, false);
      setStatus(`已删除 ${ticker}。`);
    }
    function removeSelectedItems() {
      if (!hasSelection.value) {
        return;
      }
      const selected = new Set(selectedTickers.value);
      replaceCartItems(cart.value.items.filter((item) => !selected.has(item.ticker)));
      selectedTickers.value = [];
      setStatus("已删除选中的物品。");
    }
    function clearCart() {
      if (cart.value.items.length === 0) {
        return;
      }
      replaceCartItems([]);
      selectedTickers.value = [];
      setStatus("购物车已清空。");
    }
    function importFromText() {
      if (!importText.value.trim()) {
        setStatus("请先粘贴 JSON。", true);
        return;
      }
      try {
        applyImportedCart(JSON.parse(importText.value));
      } catch {
        setStatus("JSON 解析失败。", true);
      }
    }
    function uploadImportJson() {
      uploadJson((json) => applyImportedCart(json));
    }
    function applyImportedCart(json) {
      try {
        const imported = parseCartImport(json);
        cart.value.name = normalizeCartName(imported.name ?? cart.value.name);
        if (imported.exchange) {
          cart.value.exchange = imported.exchange;
        }
        replaceCartItems(imported.items);
        selectedTickers.value = [];
        importText.value = "";
        setStatus(`已识别 ${imported.items.length} 种物品。`);
      } catch (error) {
        const message = error instanceof Error ? error.message : "无法识别购物车 JSON。";
        setStatus(message, true);
      }
    }
    function generateAct() {
      cart.value.name = normalizeCartName(cart.value.name);
      replaceCartItems(normalizeCartItems(cart.value.items));
      const pkg = buildActionPackage(cart.value);
      if (!pkg) {
        setStatus("请先选择空间站，并确保购物车里至少有一个有效物品。", true);
        return;
      }
      const existing = userData.actionPackages.find((entry) => entry.global.name === pkg.global.name);
      if (existing) {
        const index = userData.actionPackages.indexOf(existing);
        userData.actionPackages[index] = pkg;
      } else {
        userData.actionPackages.push(pkg);
      }
      const commandName = pkg.global.name.trim().replace(/\s+/g, "_");
      showBuffer(`XIT ACT_${commandName}`);
      setStatus(`已生成 ACT 包 ${pkg.global.name}。`);
    }
    function setStatus(message, isError = false) {
      statusMessage.value = message;
      statusError.value = isError;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(_ctx.$style.page)
      }, [
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: generateAct
            }, {
              default: withCtx(() => [..._cache[5] || (_cache[5] = [
                createTextVNode("生成 ACT", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: importFromText
            }, {
              default: withCtx(() => [..._cache[6] || (_cache[6] = [
                createTextVNode("识别 JSON", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: uploadImportJson
            }, {
              default: withCtx(() => [..._cache[7] || (_cache[7] = [
                createTextVNode("上传 JSON", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              dark: "",
              disabled: !unref(hasSelection),
              onClick: removeSelectedItems
            }, {
              default: withCtx(() => [..._cache[8] || (_cache[8] = [
                createTextVNode("删除选中", -1)
              ])]),
              _: 1
            }, 8, ["disabled"]),
            createVNode(_sfc_main$1, {
              dark: "",
              disabled: unref(cart).items.length === 0,
              onClick: clearCart
            }, {
              default: withCtx(() => [..._cache[9] || (_cache[9] = [
                createTextVNode("清空全部", -1)
              ])]),
              _: 1
            }, 8, ["disabled"])
          ]),
          _: 1
        }),
        createBaseVNode("div", {
          class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).DraftConditionEditor.form, _ctx.$style.formCard])
        }, [
          createVNode(SectionHeader, null, {
            default: withCtx(() => [..._cache[10] || (_cache[10] = [
              createTextVNode("购物车", -1)
            ])]),
            _: 1
          }),
          createBaseVNode("form", null, [
            createVNode(_sfc_main$4, { label: "名称" }, {
              default: withCtx(() => [
                createVNode(_sfc_main$3, {
                  modelValue: unref(cart).name,
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => unref(cart).name = $event)
                }, null, 8, ["modelValue"])
              ]),
              _: 1
            }),
            createVNode(_sfc_main$4, { label: "空间站" }, {
              default: withCtx(() => [
                createVNode(SelectInput, {
                  modelValue: unref(cart).exchange,
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => unref(cart).exchange = $event),
                  options: unref(exchangeOptions)
                }, null, 8, ["modelValue", "options"])
              ]),
              _: 1
            }),
            createVNode(_sfc_main$4, { label: "站点" }, {
              default: withCtx(() => [
                createBaseVNode("span", {
                  class: normalizeClass(_ctx.$style.secondaryText)
                }, toDisplayString(unref(stationName)), 3)
              ]),
              _: 1
            }),
            createVNode(_sfc_main$4, { label: "仓库" }, {
              default: withCtx(() => [
                createBaseVNode("span", {
                  class: normalizeClass(_ctx.$style.secondaryText)
                }, toDisplayString(unref(warehouseName)), 3)
              ]),
              _: 1
            }),
            createVNode(_sfc_main$4, { label: "汇总" }, {
              default: withCtx(() => [
                createBaseVNode("span", {
                  class: normalizeClass(_ctx.$style.secondaryText)
                }, toDisplayString(unref(cart).items.length) + " 种 / " + toDisplayString(unref(totalUnits).toLocaleString()) + " 件 / " + toDisplayString(unref(fixed02)(unref(totalWeight))) + " t / " + toDisplayString(unref(fixed02)(unref(totalVolume))) + " m³ ", 3)
              ]),
              _: 1
            }),
            createVNode(_sfc_main$4, { label: "识别 XIT JSON" }, {
              default: withCtx(() => [
                withDirectives(createBaseVNode("textarea", {
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(importText) ? importText.value = $event : null),
                  class: normalizeClass([_ctx.$style.surfaceInput, _ctx.$style.jsonInput]),
                  spellcheck: "false",
                  placeholder: '粘贴 XIT ACT JSON 或 { "COF": 100 } 这样的物品清单'
                }, null, 2), [
                  [vModelText, unref(importText)]
                ])
              ]),
              _: 1
            }),
            unref(statusMessage) ? (openBlock(), createBlock(_sfc_main$4, {
              key: 0,
              label: "状态"
            }, {
              default: withCtx(() => [
                createBaseVNode("span", {
                  class: normalizeClass([unref(statusError) ? _ctx.$style.statusError : _ctx.$style.statusOk])
                }, toDisplayString(unref(statusMessage)), 3)
              ]),
              _: 1
            })) : createCommentVNode("", true)
          ])
        ], 2),
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.layout)
        }, [
          createBaseVNode("section", {
            class: normalizeClass(_ctx.$style.section)
          }, [
            createVNode(SectionHeader, null, {
              default: withCtx(() => [..._cache[11] || (_cache[11] = [
                createTextVNode("物品目录", -1)
              ])]),
              _: 1
            }),
            createBaseVNode("div", {
              class: normalizeClass(_ctx.$style.panel)
            }, [
              withDirectives(createBaseVNode("input", {
                "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(search) ? search.value = $event : null),
                class: normalizeClass([_ctx.$style.surfaceInput, _ctx.$style.searchInput]),
                type: "text",
                placeholder: "搜索 ticker 或名称",
                onKeydown: withKeys(withModifiers(addFirstFilteredMaterial, ["prevent"]), ["enter"])
              }, null, 42, _hoisted_1), [
                [vModelText, unref(search)]
              ]),
              createBaseVNode("div", {
                class: normalizeClass(_ctx.$style.materialList)
              }, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(unref(filteredMaterials), (material) => {
                  return openBlock(), createElementBlock("div", {
                    key: material.ticker,
                    class: normalizeClass(_ctx.$style.materialRow),
                    draggable: "true",
                    onDragstart: ($event) => onCatalogDragStart($event, material.ticker)
                  }, [
                    createBaseVNode("div", {
                      class: normalizeClass(_ctx.$style.materialMeta)
                    }, [
                      createBaseVNode("strong", {
                        class: normalizeClass(_ctx.$style.materialTicker)
                      }, toDisplayString(material.ticker), 3),
                      createBaseVNode("span", {
                        class: normalizeClass(_ctx.$style.materialName)
                      }, toDisplayString(material.name), 3)
                    ], 2),
                    createVNode(_sfc_main$1, {
                      primary: "",
                      inline: "",
                      onClick: ($event) => addMaterial(material.ticker)
                    }, {
                      default: withCtx(() => [..._cache[12] || (_cache[12] = [
                        createTextVNode("添加", -1)
                      ])]),
                      _: 2
                    }, 1032, ["onClick"])
                  ], 42, _hoisted_2);
                }), 128)),
                unref(filteredMaterials).length === 0 ? (openBlock(), createElementBlock("div", {
                  key: 0,
                  class: normalizeClass(_ctx.$style.emptyState)
                }, "没有匹配的物品。", 2)) : createCommentVNode("", true)
              ], 2)
            ], 2)
          ], 2),
          createBaseVNode("section", {
            class: normalizeClass(_ctx.$style.section)
          }, [
            createVNode(SectionHeader, null, {
              default: withCtx(() => [..._cache[13] || (_cache[13] = [
                createTextVNode("购物车明细", -1)
              ])]),
              _: 1
            }),
            createBaseVNode("div", {
              class: normalizeClass([_ctx.$style.panel, _ctx.$style.dropzone, unref(cartDropActive) ? _ctx.$style.dropActive : ""]),
              onDragover: _cache[4] || (_cache[4] = withModifiers(($event) => cartDropActive.value = true, ["prevent"])),
              onDragleave: onCartDragLeave,
              onDrop: onCartDrop
            }, [
              createBaseVNode("table", {
                class: normalizeClass(_ctx.$style.cartTable)
              }, [
                createBaseVNode("thead", null, [
                  createBaseVNode("tr", null, [
                    createVNode(GripHeaderCell),
                    createBaseVNode("th", {
                      class: normalizeClass(_ctx.$style.checkboxColumn)
                    }, [
                      createBaseVNode("input", {
                        checked: unref(allSelected),
                        class: normalizeClass(_ctx.$style.checkbox),
                        type: "checkbox",
                        onChange: onSelectAllChange
                      }, null, 42, _hoisted_3)
                    ], 2),
                    _cache[14] || (_cache[14] = createBaseVNode("th", null, "物品", -1)),
                    createBaseVNode("th", {
                      class: normalizeClass(_ctx.$style.amountColumn)
                    }, "数量", 2),
                    createBaseVNode("th", {
                      class: normalizeClass(_ctx.$style.metricColumn)
                    }, "重量", 2),
                    createBaseVNode("th", {
                      class: normalizeClass(_ctx.$style.metricColumn)
                    }, "体积", 2),
                    createBaseVNode("th", {
                      class: normalizeClass(_ctx.$style.actionColumn)
                    }, null, 2)
                  ])
                ]),
                unref(cart).items.length === 0 ? (openBlock(), createElementBlock("tbody", _hoisted_4, [
                  createBaseVNode("tr", null, [
                    createBaseVNode("td", {
                      colspan: "7",
                      class: normalizeClass(_ctx.$style.emptyState)
                    }, " 把左侧物品拖到这里，或点击“添加”放入购物车。 ", 2)
                  ])
                ])) : withDirectives((openBlock(), createElementBlock("tbody", _hoisted_5, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(unref(cartRows), (row) => {
                    return openBlock(), createElementBlock("tr", {
                      key: row.item.ticker
                    }, [
                      createVNode(GripCell),
                      createBaseVNode("td", {
                        class: normalizeClass(_ctx.$style.checkboxColumn)
                      }, [
                        createBaseVNode("input", {
                          checked: isSelected(row.item.ticker),
                          class: normalizeClass(_ctx.$style.checkbox),
                          type: "checkbox",
                          onChange: ($event) => onSelectChange($event, row.item.ticker)
                        }, null, 42, _hoisted_6)
                      ], 2),
                      createBaseVNode("td", {
                        class: normalizeClass(_ctx.$style.materialCell)
                      }, [
                        createBaseVNode("strong", null, toDisplayString(row.item.ticker), 1),
                        createBaseVNode("span", null, toDisplayString(row.material?.name ?? "未知物品"), 1)
                      ], 2),
                      createBaseVNode("td", {
                        class: normalizeClass(_ctx.$style.amountColumn)
                      }, [
                        withDirectives(createBaseVNode("input", {
                          "onUpdate:modelValue": ($event) => row.item.amount = $event,
                          class: normalizeClass([_ctx.$style.surfaceInput, _ctx.$style.amountInput]),
                          min: "1",
                          step: "1",
                          type: "number",
                          onChange: ($event) => normalizeAmount(row.item)
                        }, null, 42, _hoisted_7), [
                          [
                            vModelText,
                            row.item.amount,
                            void 0,
                            { number: true }
                          ]
                        ])
                      ], 2),
                      createBaseVNode("td", {
                        class: normalizeClass(_ctx.$style.metricCell)
                      }, toDisplayString(row.material ? `${unref(fixed02)(row.material.weight * row.item.amount)} t` : "--"), 3),
                      createBaseVNode("td", {
                        class: normalizeClass(_ctx.$style.metricCell)
                      }, toDisplayString(row.material ? `${unref(fixed02)(row.material.volume * row.item.amount)} m³` : "--"), 3),
                      createBaseVNode("td", {
                        class: normalizeClass(_ctx.$style.actionColumn)
                      }, [
                        createVNode(_sfc_main$1, {
                          danger: "",
                          inline: "",
                          onClick: ($event) => removeItem(row.item.ticker)
                        }, {
                          default: withCtx(() => [..._cache[15] || (_cache[15] = [
                            createTextVNode("删除", -1)
                          ])]),
                          _: 2
                        }, 1032, ["onClick"])
                      ], 2)
                    ]);
                  }), 128))
                ])), [
                  [unref(so), [unref(cart).items, unref(grip).draggable]]
                ])
              ], 2)
            ], 34)
          ], 2)
        ], 2)
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
