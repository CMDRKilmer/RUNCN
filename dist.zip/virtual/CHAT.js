import xit from "./xit-registry.js";
import CHAT from "./CHAT.vue.js";
xit.add({
  command: "CHAT",
  name: "FIO 聊天",
  description: "提供星球聊天的只读访问。",
  mandatoryParameters: "星球标识符",
  component: () => CHAT
});
