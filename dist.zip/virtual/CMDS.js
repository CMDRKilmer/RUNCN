import xit from "./xit-registry.js";
import _sfc_main from "./CMDS.vue.js";
xit.add({
  command: "CMDS",
  name: "XIT 命令列表",
  description: "可用的 XIT 命令列表。",
  component: () => _sfc_main
});
