import LoadingSpinner from "./LoadingSpinner.vue.js";
import StatusFilter from "./StatusFilter.vue.js";
import ProgressBarWithText from "./ProgressBarWithText.vue.js";
import { contractsStore } from "./contracts.js";
import _sfc_main$1 from "./ContractLink.vue.js";
import PartnerLink from "./PartnerLink.vue.js";
import MaterialIcon from "./MaterialIcon.vue.js";
import ShipmentIcon from "./ShipmentIcon.vue.js";
import { isFactionContract, canAcceptContract, calculateContractTotals, formatAmount, calculateProgress, getStatusClass, getStatusText, isSelfCondition, calculateContractReceivable } from "./utils4.js";
import { timestampEachSecond } from "./dayjs.js";
import { objectId } from "./object-id.js";
import dayjs from "./dayjs.min.js";
import { isEmpty } from "./is-empty.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createVNode, createElementVNode as createBaseVNode, createCommentVNode, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { ref, unref } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CONTFF",
  setup(__props) {
    const activeFilters = ref(
      /* @__PURE__ */ new Set(["OPEN", "CLOSED", "PARTIALLY_FULFILLED", "DEADLINE_EXCEEDED"])
    );
    const showFilters = ref(true);
    const filtered = computed(
      () => (contractsStore.all.value ?? []).filter((c) => isFactionContract(c)).filter((c) => activeFilters.value.has(c.status)).sort(compareContracts)
    );
    function compareContracts(a, b) {
      if (canAcceptContract(a) && !canAcceptContract(b)) {
        return -1;
      }
      if (canAcceptContract(b) && !canAcceptContract(a)) {
        return 1;
      }
      return (b.date?.timestamp ?? 0) - (a.date?.timestamp ?? 0);
    }
    const totals = computed(() => calculateContractTotals(filtered.value));
    function getIcons(contract) {
      const result = [];
      for (const condition of contract.conditions) {
        switch (condition.type) {
          case "DELIVERY_SHIPMENT": {
            if (isSelfCondition(contract, condition)) {
              result.push({
                type: "SHIPMENT",
                shipmentId: condition.shipmentItemId,
                fulfilled: condition.status === "FULFILLED"
              });
              continue;
            }
            break;
          }
          case "PROVISION":
          case "PICKUP_SHIPMENT": {
            continue;
          }
        }
        const quantity = condition.quantity;
        if (quantity === null || quantity === void 0 || quantity.material === null || quantity.material === void 0) {
          continue;
        }
        result.push({
          type: "MATERIAL",
          ticker: quantity.material.ticker,
          amount: quantity.amount,
          fulfilled: condition.status === "FULFILLED"
        });
      }
      return result;
    }
    function getReceivable(contract) {
      return calculateContractReceivable(contract);
    }
    function getDeadline(contract) {
      const deadline = contract.dueDate;
      if (!deadline || deadline.timestamp === void 0 || deadline.timestamp === null) return "-";
      const remaining = deadline.timestamp - timestampEachSecond.value;
      if (remaining <= 0) return "已逾期";
      const d = dayjs.duration(remaining);
      if (d.days() > 0) return `${d.days()}天 ${d.hours()}小时`;
      if (d.hours() > 0) return `${d.hours()}小时 ${d.minutes()}分钟`;
      return `${d.minutes()}分钟`;
    }
    return (_ctx, _cache) => {
      return !unref(contractsStore).fetched ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(_ctx.$style.container)
      }, [
        createVNode(StatusFilter, {
          modelValue: activeFilters.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => activeFilters.value = $event),
          "show-filters": showFilters.value,
          "onUpdate:showFilters": _cache[1] || (_cache[1] = ($event) => showFilters.value = $event)
        }, null, 8, ["modelValue", "show-filters"]),
        totals.value.currency ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(_ctx.$style.totalsBar)
        }, [
          createBaseVNode("span", null, "共 " + toDisplayString(filtered.value.length) + " 单", 1),
          totals.value.hasMixedCurrency ? (openBlock(), createElementBlock("span", {
            key: 0,
            class: normalizeClass(_ctx.$style.warningText)
          }, " ⚠️ 检测到不同货币，金额统计可能不准确 ", 2)) : createCommentVNode("", true),
          totals.value.receivable > 0 ? (openBlock(), createElementBlock("span", {
            key: 1,
            class: normalizeClass(_ctx.$style.receivableText)
          }, " 待收: " + toDisplayString(unref(formatAmount)(totals.value.receivable, totals.value.currency)), 3)) : createCommentVNode("", true)
        ], 2)) : createCommentVNode("", true),
        createBaseVNode("table", null, [
          _cache[2] || (_cache[2] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "合同"),
              createBaseVNode("th", null, "物品"),
              createBaseVNode("th", null, "对方"),
              createBaseVNode("th", null, "待收款"),
              createBaseVNode("th", null, "限期"),
              createBaseVNode("th", null, "进度"),
              createBaseVNode("th", null, "状态")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            unref(isEmpty)(filtered.value) ? (openBlock(), createElementBlock("tr", _hoisted_1, [
              createBaseVNode("td", {
                colspan: "7",
                class: normalizeClass(_ctx.$style.empty)
              }, "没有活动派系合同", 2)
            ])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(filtered.value, (contract) => {
              return openBlock(), createElementBlock("tr", {
                key: contract.id
              }, [
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, { contract }, null, 8, ["contract"])
                ]),
                createBaseVNode("td", null, [
                  createBaseVNode("div", {
                    class: normalizeClass(_ctx.$style.iconGrid)
                  }, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(getIcons(contract), (icon) => {
                      return openBlock(), createElementBlock("div", {
                        key: unref(objectId)(icon),
                        class: normalizeClass([icon.fulfilled && _ctx.$style.dimmed])
                      }, [
                        icon.type === "SHIPMENT" ? (openBlock(), createBlock(ShipmentIcon, {
                          key: 0,
                          size: "small",
                          "shipment-id": icon.shipmentId
                        }, null, 8, ["shipment-id"])) : createCommentVNode("", true),
                        icon.type === "MATERIAL" ? (openBlock(), createBlock(MaterialIcon, {
                          key: 1,
                          size: "small",
                          compact: "",
                          ticker: icon.ticker,
                          amount: icon.amount
                        }, null, 8, ["ticker", "amount"])) : createCommentVNode("", true)
                      ], 2);
                    }), 128))
                  ], 2)
                ]),
                createBaseVNode("td", null, [
                  createVNode(PartnerLink, { contract }, null, 8, ["contract"])
                ]),
                createBaseVNode("td", {
                  class: normalizeClass(_ctx.$style.receivable)
                }, toDisplayString(unref(formatAmount)(getReceivable(contract).total, getReceivable(contract).currency)), 3),
                createBaseVNode("td", {
                  class: normalizeClass(_ctx.$style.deadlineCell)
                }, toDisplayString(getDeadline(contract)), 3),
                createBaseVNode("td", null, [
                  createVNode(ProgressBarWithText, {
                    current: unref(calculateProgress)(contract).fulfilled,
                    total: unref(calculateProgress)(contract).total,
                    "show-text": true
                  }, null, 8, ["current", "total"])
                ]),
                createBaseVNode("td", {
                  class: normalizeClass(_ctx.$style[unref(getStatusClass)(contract.status)])
                }, toDisplayString(unref(getStatusText)(contract.status)), 3)
              ]);
            }), 128))
          ])
        ])
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
