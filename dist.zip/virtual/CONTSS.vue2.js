import LoadingSpinner from "./LoadingSpinner.vue.js";
import StatusFilter from "./StatusFilter.vue.js";
import { contractsStore } from "./contracts.js";
import ContractOverviewRow from "./ContractOverviewRow.vue.js";
import { canAcceptContract, calculateContractTotals, formatAmount } from "./utils4.js";
import { isEmpty } from "./is-empty.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createVNode, createElementVNode as createBaseVNode, createCommentVNode, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { ref, unref } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CONTSS",
  setup(__props) {
    const activeFilters = ref(
      /* @__PURE__ */ new Set(["OPEN", "CLOSED", "PARTIALLY_FULFILLED", "DEADLINE_EXCEEDED"])
    );
    const showFilters = ref(true);
    const filtered = computed(
      () => (contractsStore.all.value ?? []).filter((c) => activeFilters.value.has(c.status)).sort(compareContracts)
    );
    function compareContracts(a, b) {
      if (canAcceptContract(a) && !canAcceptContract(b)) {
        return -1;
      }
      if (canAcceptContract(b) && !canAcceptContract(a)) {
        return 1;
      }
      return (b.date?.timestamp ?? 0) - (a.date?.timestamp ?? 0);
    }
    const totals = computed(() => calculateContractTotals(filtered.value));
    return (_ctx, _cache) => {
      return !unref(contractsStore).fetched ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(_ctx.$style.container)
      }, [
        createVNode(StatusFilter, {
          modelValue: activeFilters.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => activeFilters.value = $event),
          "show-filters": showFilters.value,
          "onUpdate:showFilters": _cache[1] || (_cache[1] = ($event) => showFilters.value = $event)
        }, null, 8, ["modelValue", "show-filters"]),
        totals.value.currency ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(_ctx.$style.totalsBar)
        }, [
          createBaseVNode("span", null, "共 " + toDisplayString(filtered.value.length) + " 单", 1),
          totals.value.hasMixedCurrency ? (openBlock(), createElementBlock("span", {
            key: 0,
            class: normalizeClass(_ctx.$style.warningText)
          }, " ⚠️ 检测到不同货币，金额统计可能不准确 ", 2)) : createCommentVNode("", true),
          totals.value.receivable > 0 ? (openBlock(), createElementBlock("span", {
            key: 1,
            class: normalizeClass(_ctx.$style.receivableText)
          }, " 待收: " + toDisplayString(unref(formatAmount)(totals.value.receivable, totals.value.currency)), 3)) : createCommentVNode("", true),
          totals.value.payable > 0 ? (openBlock(), createElementBlock("span", {
            key: 2,
            class: normalizeClass(_ctx.$style.payableText)
          }, " 应付: " + toDisplayString(unref(formatAmount)(totals.value.payable, totals.value.currency)), 3)) : createCommentVNode("", true)
        ], 2)) : createCommentVNode("", true),
        createBaseVNode("table", null, [
          _cache[2] || (_cache[2] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "合同"),
              createBaseVNode("th", null, "物品"),
              createBaseVNode("th", null, "对方"),
              createBaseVNode("th", null, "待收款"),
              createBaseVNode("th", null, "应付款"),
              createBaseVNode("th", null, "进度"),
              createBaseVNode("th", null, "状态")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            unref(isEmpty)(filtered.value) ? (openBlock(), createElementBlock("tr", _hoisted_1, [
              createBaseVNode("td", {
                colspan: "7",
                class: normalizeClass(_ctx.$style.empty)
              }, "没有活动合同", 2)
            ])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(filtered.value, (contract) => {
              return openBlock(), createBlock(ContractOverviewRow, {
                key: contract.id,
                contract
              }, null, 8, ["contract"]);
            }), 128))
          ])
        ])
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
