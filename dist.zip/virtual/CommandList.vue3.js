const inline = "rp-CommandList__inline___74234e6";
const style0 = {
  inline
};
export {
  style0 as default,
  inline
};
