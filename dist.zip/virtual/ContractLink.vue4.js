import _sfc_main from "./ContractLink.vue3.js";
export {
  _sfc_main as default
};
