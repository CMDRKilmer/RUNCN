import xit from "./xit-registry.js";
import _sfc_main from "./DEV.vue.js";
xit.add({
  command: "DEV",
  name: "开发菜单",
  description: "开发菜单。",
  component: () => _sfc_main
});
