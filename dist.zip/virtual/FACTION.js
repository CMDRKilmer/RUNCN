import xit from "./xit-registry.js";
import _sfc_main from "./FactionPanel.vue.js";
xit.add({
  command: ["FACTION"],
  name: "组织管理面板",
  description: "为组织提供内部管理面板。",
  optionalParameters: "tab",
  component: () => _sfc_main
});
