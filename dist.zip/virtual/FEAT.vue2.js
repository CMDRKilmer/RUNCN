import features from "./feature-registry.js";
import { C } from "./prun-css.js";
import SectionHeader from "./SectionHeader.vue.js";
import _sfc_main$4 from "./Active.vue.js";
import _sfc_main$3 from "./TextInput.vue.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import { userData } from "./user-data.js";
import removeArrayElement from "./remove-array-element.js";
import { saveUserData } from "./user-data-serializer.js";
import _sfc_main$2 from "./Commands.vue.js";
import { isEmpty } from "./is-empty.js";
import { reactive, ref, unref } from "./reactivity.esm-bundler.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, createBlock, createCommentVNode, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { toDisplayString, normalizeClass } from "./shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 1 };
const _hoisted_3 = ["onClick"];
const changed = reactive({});
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FEAT",
  setup(__props) {
    if (userData.settings.mode === void 0) {
      userData.settings.mode = "BASIC";
    }
    const isFullMode = userData.settings.mode === "FULL";
    const disabledFeatures = computed(() => new Set(userData.settings.disabled));
    const available = isFullMode ? features.registry : features.registry.filter((x) => !x.advanced);
    const advanced = features.registry.filter((x) => x.advanced);
    const sorted = available.sort((a, b) => {
      const aDisabled = disabledFeatures.value.has(a.id);
      const bDisabled = disabledFeatures.value.has(b.id);
      if (aDisabled && !bDisabled) {
        return -1;
      }
      if (!aDisabled && bDisabled) {
        return 1;
      }
      return a.id.localeCompare(b.id);
    });
    const searchIndex = /* @__PURE__ */ new Map();
    for (const feature of sorted) {
      searchIndex.set(feature.id, `${feature.id} ${feature.description}`.toLowerCase());
    }
    const searchQuery = ref("");
    const filtered = computed(() => {
      const keywords = searchQuery.value.toLowerCase().replaceAll(/\W/g, " ").split(/\s+/).filter(Boolean);
      if (keywords.length === 0) {
        return sorted;
      }
      return sorted.filter((feature) => keywords.some((x) => searchIndex.get(feature.id).includes(x)));
    });
    function toggleFeature(id) {
      if (changed[id]) {
        delete changed[id];
      } else {
        changed[id] = true;
      }
      const disabled = userData.settings.disabled;
      if (disabledFeatures.value.has(id)) {
        removeArrayElement(disabled, id);
      } else {
        disabled.push(id);
      }
      void saveUserData();
    }
    function toggleClass(id) {
      return disabledFeatures.value.has(id) ? void 0 : [C.RadioItem.active, C.effects.shadowPrimary];
    }
    async function onReloadClick() {
      await saveUserData();
      window.location.reload();
    }
    async function onChangeModeClick() {
      if (isFullMode) {
        userData.settings.mode = "BASIC";
      } else {
        userData.settings.mode = "FULL";
      }
      await saveUserData();
      window.location.reload();
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("form", {
          class: normalizeClass(_ctx.$style.form)
        }, [
          createVNode(_sfc_main$2, { label: "切换功能集" }, {
            default: withCtx(() => [
              createVNode(_sfc_main$1, {
                primary: "",
                onClick: onChangeModeClick
              }, {
                default: withCtx(() => [
                  createTextVNode(" 切换到 " + toDisplayString(isFullMode ? "基础模式" : "完整模式"), 1)
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_sfc_main$4, {
            class: normalizeClass(_ctx.$style.warningRoot),
            label: "搜索"
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$3, {
                modelValue: searchQuery.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => searchQuery.value = $event)
              }, null, 8, ["modelValue"]),
              !unref(isEmpty)(Object.keys(unref(changed))) ? (openBlock(), createBlock(_sfc_main$1, {
                key: 0,
                primary: "",
                class: normalizeClass(_ctx.$style.warning),
                onClick: onReloadClick
              }, {
                default: withCtx(() => [..._cache[1] || (_cache[1] = [
                  createTextVNode(" 重启游戏以应用更改 ", -1)
                ])]),
                _: 1
              }, 8, ["class"])) : createCommentVNode("", true)
            ]),
            _: 1
          }, 8, ["class"])
        ], 2),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [
            createTextVNode(" 功能: " + toDisplayString(unref(sorted).length) + " ", 1),
            disabledFeatures.value.size > 0 ? (openBlock(), createElementBlock("span", _hoisted_1, "(" + toDisplayString(disabledFeatures.value.size) + " 已关闭) ", 1)) : createCommentVNode("", true),
            !isFullMode ? (openBlock(), createElementBlock("span", _hoisted_2, "(+" + toDisplayString(unref(advanced).length) + " 个完整模式可用功能)", 1)) : createCommentVNode("", true)
          ]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(filtered.value, (feature) => {
              return openBlock(), createElementBlock("tr", {
                key: feature.id
              }, [
                createBaseVNode("td", {
                  class: normalizeClass(_ctx.$style.row),
                  onClick: ($event) => toggleFeature(feature.id)
                }, [
                  createBaseVNode("div", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).RadioItem.indicator, _ctx.$style.indicator, toggleClass(feature.id)])
                  }, null, 2),
                  createBaseVNode("div", null, [
                    createBaseVNode("div", {
                      class: normalizeClass(_ctx.$style.id)
                    }, toDisplayString(feature.id), 3),
                    createBaseVNode("div", {
                      class: normalizeClass(_ctx.$style.description)
                    }, toDisplayString(feature.description), 3)
                  ])
                ], 10, _hoisted_3)
              ]);
            }), 128))
          ])
        ]),
        !isFullMode ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
          createVNode(SectionHeader, null, {
            default: withCtx(() => [..._cache[2] || (_cache[2] = [
              createTextVNode("完整模式功能", -1)
            ])]),
            _: 1
          }),
          createBaseVNode("table", null, [
            createBaseVNode("tbody", null, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(advanced), (feature) => {
                return openBlock(), createElementBlock("tr", {
                  key: feature.id
                }, [
                  createBaseVNode("td", {
                    class: normalizeClass([_ctx.$style.row, _ctx.$style.rowFull])
                  }, [
                    createBaseVNode("div", {
                      class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).RadioItem.indicator, ("C" in _ctx ? _ctx.C : unref(C)).RadioItem.disabled, _ctx.$style.indicator])
                    }, null, 2),
                    createBaseVNode("div", null, [
                      createBaseVNode("div", {
                        class: normalizeClass(_ctx.$style.id)
                      }, toDisplayString(feature.id), 3),
                      createBaseVNode("div", {
                        class: normalizeClass(_ctx.$style.description)
                      }, toDisplayString(feature.description), 3)
                    ])
                  ], 2)
                ]);
              }), 128))
            ])
          ])
        ], 64)) : createCommentVNode("", true)
      ]);
    };
  }
});
export {
  _sfc_main as default
};
