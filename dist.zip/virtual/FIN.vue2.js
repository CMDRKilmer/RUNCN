import { calculateLocationAssets } from "./financials.js";
import KeyFigures from "./KeyFigures.vue.js";
import _sfc_main$1 from "./FinHeader.vue.js";
import { formatCurrency, fixed0, fixed1, fixed2, percent0, percent1, percent2 } from "./format.js";
import { liveBalanceSummary } from "./balance-sheet-live.js";
import { userData } from "./user-data.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
import { toDisplayString } from "./shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FIN",
  setup(__props) {
    const locations = computed(() => calculateLocationAssets());
    function formatRatio(ratio) {
      if (ratio === void 0) {
        return "--";
      }
      if (!isFinite(ratio)) {
        return "N/A";
      }
      const absRatio = Math.abs(ratio);
      if (absRatio > 1e3) {
        return ratio > 0 ? "> 1,000" : "< -1,000";
      }
      if (absRatio > 100) {
        return fixed0(ratio);
      }
      if (absRatio > 10) {
        return fixed1(ratio);
      }
      return fixed2(ratio);
    }
    function formatPercentage(ratio) {
      if (ratio === void 0) {
        return "--";
      }
      if (!isFinite(ratio)) {
        return "N/A";
      }
      const absRatio = Math.abs(ratio);
      if (absRatio > 10) {
        return ratio > 0 ? "> 1,000%" : "< -1,000%";
      }
      if (absRatio > 1) {
        return percent0(ratio);
      }
      if (absRatio > 0.1) {
        return percent1(ratio);
      }
      return percent2(ratio);
    }
    const figures = computed(() => {
      return [
        {
          name: "速动资产",
          value: formatCurrency(liveBalanceSummary.quickAssets),
          tooltip: "速动资产包括：现金及现金等价物、流动应收账款和流动应收贷款（详见 XIT FINBS）。这些资产是流动性较高的资产，用于速动比率计算。"
        },
        {
          name: "流动资产",
          value: formatCurrency(liveBalanceSummary.currentAssets)
        },
        { name: "总资产", value: formatCurrency(liveBalanceSummary.assets) },
        { name: "权益", value: formatCurrency(liveBalanceSummary.equity) },
        {
          name: "速动负债",
          value: formatCurrency(liveBalanceSummary.quickLiabilities),
          tooltip: "速动负债包括：流动应付账款和流动应付贷款（详见 XIT FINBS）。这些负债代表即时的财务义务，用于速动比率计算。"
        },
        {
          name: "流动负债",
          value: formatCurrency(liveBalanceSummary.currentLiabilities)
        },
        {
          name: "总负债",
          value: formatCurrency(liveBalanceSummary.liabilities)
        },
        {
          name: "清算价值",
          hidden: !userData.fullEquityMode,
          value: formatCurrency(liveBalanceSummary.liquidationValue),
          tooltip: "公司所有可直接变现资产的市场价值。清算价值不包括飞船、总部升级和 ARC 等资产，因为它们无法在市场上出售。"
        },
        {
          name: "速动比率",
          value: formatRatio(liveBalanceSummary.acidTestRatio),
          tooltip: "速动比率（酸性测试比率）将公司的速动资产与速动负债进行比较，以判断是否有足够的现金来支付即时负债，如短期债务。一般来说，比率 1.0 或以上表明公司能够偿还短期债务，低于 1.0 则表明可能难以偿还。"
        },
        {
          name: "负债比率",
          value: formatPercentage(liveBalanceSummary.debtRatio),
          tooltip: "负债比率定义为总负债与总资产的比率。负债比率大于 100% 表示公司负债超过资产，低于 100%则表示公司资产超过负债。"
        }
      ];
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_sfc_main$1, null, {
          default: withCtx(() => [..._cache[0] || (_cache[0] = [
            createTextVNode("关键指标", -1)
          ])]),
          _: 1
        }),
        createVNode(KeyFigures, { figures: unref(figures) }, null, 8, ["figures"]),
        createVNode(_sfc_main$1, null, {
          default: withCtx(() => [..._cache[1] || (_cache[1] = [
            createTextVNode("库存明细", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("table", null, [
          _cache[2] || (_cache[2] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "名称"),
              createBaseVNode("th", null, "非流动资产"),
              createBaseVNode("th", null, "流动资产"),
              createBaseVNode("th", null, "总资产")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(locations), (location) => {
              return openBlock(), createElementBlock("tr", {
                key: location.name
              }, [
                createBaseVNode("td", null, toDisplayString(location.name), 1),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(location.nonCurrent)), 1),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(location.current)), 1),
                createBaseVNode("td", null, toDisplayString(unref(fixed0)(location.total)), 1)
              ]);
            }), 128))
          ])
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
