import xit from "./xit-registry.js";
import FINCH from "./FINCH.vue.js";
xit.add({
  command: ["FINCH"],
  name: "财务图表",
  description: "权益和资产的财务图表。",
  optionalParameters: "图表标识符",
  contextItems: () => [
    { cmd: "XIT FIN" },
    { cmd: "XIT FINBS" },
    { cmd: "XIT FINPR" },
    { cmd: "XIT SET FIN" }
  ],
  component: () => FINCH
});
