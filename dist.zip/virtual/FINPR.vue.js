import _sfc_main from "./FINPR.vue2.js";
/* empty css           */
import _export_sfc from "./plugin-vue_export-helper.js";
const FINPR = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-3df2b258"]]);
export {
  FINPR as default
};
