import { vModelText, withKeys } from "./runtime-dom.esm-bundler.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import MaterialIcon from "./MaterialIcon.vue.js";
import { fetchProductionSummary, FactionApiError, updateProductionQuantity, deleteProductionByMember, aggregateMyProduction, reportProduction } from "./use-faction-api.js";
import { sitesStore } from "./sites.js";
import { materialsStore } from "./materials.js";
import { sortMaterials } from "./sort-materials.js";
import { fixed0, fixed1, fixed2 } from "./format.js";
import $style from "./FactionDailyProduction.module.css.js";
import { defineComponent, computed, watch, onMounted, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, withDirectives, Fragment, createCommentVNode, renderList, createBlock, nextTick } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
const _hoisted_1 = { style: { "display": "flex", "align-items": "center", "gap": "6px" } };
const _hoisted_2 = { style: { "display": "flex", "align-items": "center", "gap": "6px" } };
const _hoisted_3 = ["onDblclick"];
const _hoisted_4 = ["onClick"];
const pageSize = 10;
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FactionDailyProduction",
  props: {
    myRole: {}
  },
  setup(__props) {
    const props = __props;
    const members = ref([]);
    const loading = ref(false);
    const error = ref("");
    const submitStatus = ref("idle");
    const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    const editingItem = ref(null);
    const searchQuery = ref("");
    const isExecutive = computed(() => props.myRole === "executive");
    const expandedCards = ref(/* @__PURE__ */ new Set());
    function toggleExpand(companyName) {
      if (expandedCards.value.has(companyName)) {
        expandedCards.value.delete(companyName);
      } else {
        expandedCards.value.add(companyName);
      }
    }
    function isExpanded(companyName) {
      return !!searchQuery.value.trim() || expandedCards.value.has(companyName);
    }
    const filteredMembers = computed(() => {
      const q = searchQuery.value.trim().toUpperCase();
      if (!q) return members.value;
      return members.value.map((m) => {
        const matched = m.items.filter((i) => i.ticker.includes(q));
        return matched.length > 0 ? { ...m, items: matched } : null;
      }).filter((m) => m !== null);
    });
    const currentPage = ref(1);
    const totalPages = computed(() => {
      const t = Math.ceil(filteredMembers.value.length / pageSize);
      return t === 0 ? 1 : t;
    });
    const paginatedMembers = computed(() => {
      const start = (currentPage.value - 1) * pageSize;
      return filteredMembers.value.slice(start, start + pageSize);
    });
    watch([searchQuery, members], () => {
      currentPage.value = 1;
    });
    const overflowingCards = ref(/* @__PURE__ */ new Set());
    const itemsWrapRefs = ref({});
    let observers = [];
    function setItemsWrapRef(el, companyName) {
      itemsWrapRefs.value[companyName] = el;
    }
    function checkOverflow(el, companyName) {
      if (el.clientHeight > 48) return;
      const overflows = el.scrollHeight > el.clientHeight;
      if (overflows) {
        overflowingCards.value.add(companyName);
      } else {
        overflowingCards.value.delete(companyName);
      }
      overflowingCards.value = new Set(overflowingCards.value);
    }
    function setupOverflowObservers() {
      observers.forEach((o) => o.disconnect());
      observers = [];
      for (const [name, el] of Object.entries(itemsWrapRefs.value)) {
        if (!el) continue;
        const observer = new ResizeObserver(() => checkOverflow(el, name));
        observer.observe(el);
        observers.push(observer);
        checkOverflow(el, name);
      }
    }
    watch(
      () => paginatedMembers.value.map((m) => m.companyName).join(","),
      async () => {
        await nextTick();
        setupOverflowObservers();
      },
      { immediate: false }
    );
    function sortedItems(items) {
      const mats = items.map((i) => materialsStore.getByTicker(i.ticker)).filter((m) => m !== void 0);
      const sorted = sortMaterials(mats);
      return sorted.map((m) => items.find((i) => i.ticker === m.ticker));
    }
    function formatQty(n) {
      const abs = Math.abs(n);
      return abs >= 1e3 ? fixed0(abs) : abs >= 100 ? fixed1(abs) : fixed2(abs);
    }
    async function loadData() {
      loading.value = true;
      error.value = "";
      try {
        const result = await fetchProductionSummary();
        members.value = result.members;
      } catch (e) {
        error.value = e instanceof FactionApiError ? e.response.message : "无法加载产出数据";
      } finally {
        loading.value = false;
      }
    }
    async function handleSubmitMyProduction() {
      if (submitStatus.value === "submitting") return;
      submitStatus.value = "submitting";
      error.value = "";
      if (!sitesStore.fetched.value) {
        error.value = "游戏数据未就绪，请稍后再试";
        submitStatus.value = "idle";
        return;
      }
      try {
        const items = await aggregateMyProduction();
        if (items.length === 0) {
          error.value = "未检测到产出数据（确认游戏已完全加载且有生产订单）";
          submitStatus.value = "idle";
          return;
        }
        await reportProduction(items);
        submitStatus.value = "ok";
        await loadData();
      } catch (e) {
        error.value = e instanceof FactionApiError ? e.response.message : "提交失败";
        submitStatus.value = "idle";
      }
    }
    function startEdit(item) {
      if (!item.id) return;
      editingItem.value = { id: item.id, quantity: item.quantity };
    }
    async function saveEdit() {
      if (!editingItem.value) return;
      try {
        await updateProductionQuantity(editingItem.value.id, editingItem.value.quantity);
        editingItem.value = null;
        await loadData();
      } catch (e) {
        error.value = e instanceof FactionApiError ? e.response.message : "更新失败";
      }
    }
    function cancelEdit() {
      editingItem.value = null;
    }
    async function handleDeleteMemberProduction(companyName) {
      try {
        await deleteProductionByMember(companyName);
        await loadData();
      } catch (e) {
        error.value = e instanceof FactionApiError ? e.response.message : "删除失败";
      }
    }
    onMounted(loadData);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          class: normalizeClass(unref($style).toolbar)
        }, [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_sfc_main$1, {
              dark: "",
              onClick: loadData
            }, {
              default: withCtx(() => [..._cache[4] || (_cache[4] = [
                createTextVNode("刷新", -1)
              ])]),
              _: 1
            }),
            createBaseVNode("span", {
              class: normalizeClass(unref($style).dateLabel)
            }, toDisplayString(unref(today)), 3)
          ]),
          createBaseVNode("div", _hoisted_2, [
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(searchQuery) ? searchQuery.value = $event : null),
              class: normalizeClass(unref($style).searchInput),
              type: "text",
              placeholder: "搜索材料...",
              autocomplete: "off"
            }, null, 2), [
              [vModelText, unref(searchQuery)]
            ]),
            createVNode(_sfc_main$1, {
              dark: "",
              disabled: unref(submitStatus) === "submitting",
              onClick: handleSubmitMyProduction
            }, {
              default: withCtx(() => [
                unref(submitStatus) === "submitting" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                  createTextVNode("上报中...")
                ], 64)) : unref(submitStatus) === "ok" ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                  createTextVNode("✓ 已上报")
                ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [
                  createTextVNode("上报我的产出")
                ], 64))
              ]),
              _: 1
            }, 8, ["disabled"])
          ])
        ], 2),
        unref(error) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(unref($style).errorMsg)
        }, toDisplayString(unref(error)), 3)) : createCommentVNode("", true),
        unref(loading) ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(unref($style).loadingMsg)
        }, "加载中...", 2)) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [
          unref(filteredMembers).length === 0 ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(unref($style).emptyMsg)
          }, toDisplayString(unref(searchQuery) ? "未找到匹配的材料" : "暂无产出数据 — 点击「上报我的产出」提交"), 3)) : createCommentVNode("", true),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).grid)
          }, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(paginatedMembers), (member) => {
              return openBlock(), createElementBlock("div", {
                key: member.companyName,
                class: normalizeClass(unref($style).card)
              }, [
                createBaseVNode("div", {
                  class: normalizeClass(unref($style).cardHeader)
                }, [
                  createBaseVNode("span", {
                    class: normalizeClass(unref($style).cardName)
                  }, [
                    createTextVNode(toDisplayString(member.companyName) + " ", 1),
                    member.username ? (openBlock(), createElementBlock("span", {
                      key: 0,
                      class: normalizeClass(unref($style).cardUsername)
                    }, toDisplayString(member.username), 3)) : createCommentVNode("", true)
                  ], 2),
                  unref(isExecutive) ? (openBlock(), createBlock(_sfc_main$1, {
                    key: 0,
                    danger: "",
                    class: normalizeClass(unref($style).deleteBtn),
                    onClick: ($event) => handleDeleteMemberProduction(member.companyName)
                  }, {
                    default: withCtx(() => [..._cache[5] || (_cache[5] = [
                      createTextVNode(" ✕ ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["class", "onClick"])) : createCommentVNode("", true)
                ], 2),
                createBaseVNode("div", {
                  ref_for: true,
                  ref: (el) => setItemsWrapRef(el, member.companyName),
                  class: normalizeClass([unref($style).itemsWrap, isExpanded(member.companyName) ? "" : unref($style).collapsed])
                }, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(sortedItems(member.items), (item) => {
                    return openBlock(), createElementBlock("div", {
                      key: item.ticker,
                      class: normalizeClass(unref($style).item),
                      onDblclick: ($event) => unref(isExecutive) && startEdit(item)
                    }, [
                      createVNode(MaterialIcon, {
                        size: "small",
                        ticker: item.ticker
                      }, null, 8, ["ticker"]),
                      unref(editingItem) && unref(editingItem).id === item.id ? withDirectives((openBlock(), createElementBlock("input", {
                        key: 0,
                        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => unref(editingItem).quantity = $event),
                        class: normalizeClass(unref($style).editInput),
                        type: "number",
                        onKeyup: [
                          withKeys(saveEdit, ["enter"]),
                          withKeys(cancelEdit, ["escape"])
                        ],
                        onBlur: saveEdit
                      }, null, 34)), [
                        [
                          vModelText,
                          unref(editingItem).quantity,
                          void 0,
                          { number: true }
                        ]
                      ]) : (openBlock(), createElementBlock("span", {
                        key: 1,
                        class: normalizeClass(unref($style).qty)
                      }, toDisplayString(formatQty(item.quantity)), 3))
                    ], 42, _hoisted_3);
                  }), 128))
                ], 2),
                !unref(searchQuery).trim() && unref(overflowingCards).has(member.companyName) ? (openBlock(), createElementBlock("div", {
                  key: 0,
                  class: normalizeClass(unref($style).expandBtn),
                  onClick: ($event) => toggleExpand(member.companyName)
                }, toDisplayString(unref(expandedCards).has(member.companyName) ? "收起 ▲" : "展开 ▼"), 11, _hoisted_4)) : createCommentVNode("", true)
              ], 2);
            }), 128))
          ], 2),
          unref(totalPages) > 1 ? (openBlock(), createElementBlock("div", {
            key: 1,
            class: normalizeClass(unref($style).pagination)
          }, [
            createVNode(_sfc_main$1, {
              dark: "",
              disabled: unref(currentPage) === 1,
              onClick: _cache[2] || (_cache[2] = ($event) => currentPage.value--)
            }, {
              default: withCtx(() => [..._cache[6] || (_cache[6] = [
                createTextVNode("上一页", -1)
              ])]),
              _: 1
            }, 8, ["disabled"]),
            createBaseVNode("span", {
              class: normalizeClass(unref($style).pageInfo)
            }, toDisplayString(unref(currentPage)) + " / " + toDisplayString(unref(totalPages)), 3),
            createVNode(_sfc_main$1, {
              dark: "",
              disabled: unref(currentPage) === unref(totalPages),
              onClick: _cache[3] || (_cache[3] = ($event) => currentPage.value++)
            }, {
              default: withCtx(() => [..._cache[7] || (_cache[7] = [
                createTextVNode("下一页", -1)
              ])]),
              _: 1
            }, 8, ["disabled"])
          ], 2)) : createCommentVNode("", true)
        ], 64))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
