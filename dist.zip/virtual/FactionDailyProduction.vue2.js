import _sfc_main from "./FactionDailyProduction.vue.js";
export {
  _sfc_main as default
};
