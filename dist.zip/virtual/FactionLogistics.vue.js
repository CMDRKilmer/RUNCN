import { vModelText } from "./runtime-dom.esm-bundler.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import { fetchLogistics, FactionApiError, createLogisticsRequest, reviewLogistics } from "./use-faction-api.js";
import { LOGISTICS_STATUS_LABELS } from "./types3.js";
import $style from "./FactionPanel.module.css.js";
import { defineComponent, computed, onMounted, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, createBlock, createCommentVNode, withDirectives, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass, normalizeStyle } from "./shared.esm-bundler.js";
const _hoisted_1 = { style: { "display": "flex", "justify-content": "space-between", "align-items": "center" } };
const _hoisted_2 = { style: { "font-weight": "bold", "font-size": "13px" } };
const _hoisted_3 = { style: { "opacity": "0.7" } };
const _hoisted_4 = { style: { "opacity": "0.5", "font-size": "11px" } };
const _hoisted_5 = {
  key: 0,
  style: { "opacity": "0.5", "font-size": "11px", "margin-top": "2px" }
};
const _hoisted_6 = {
  key: 1,
  style: { "display": "flex", "gap": "4px", "margin-top": "4px" }
};
const _hoisted_7 = {
  key: 2,
  style: { "margin-top": "4px" }
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FactionLogistics",
  props: {
    myRole: {}
  },
  setup(__props) {
    const props = __props;
    const requests = ref([]);
    const loading = ref(false);
    const error = ref("");
    const showForm = ref(false);
    const formTicker = ref("");
    const formQuantity = ref("");
    const formDestination = ref("");
    const formReason = ref("");
    const isExecutive = computed(() => props.myRole === "executive");
    const canRequest = computed(() => props.myRole !== "member");
    async function loadData() {
      loading.value = true;
      error.value = "";
      try {
        const result = await fetchLogistics();
        requests.value = result.requests;
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      } finally {
        loading.value = false;
      }
    }
    async function handleSubmit() {
      const qty = parseInt(formQuantity.value);
      if (!formTicker.value || isNaN(qty) || qty <= 0 || !formDestination.value) {
        return;
      }
      try {
        await createLogisticsRequest(
          formTicker.value.toUpperCase(),
          qty,
          formDestination.value,
          formReason.value
        );
        showForm.value = false;
        formTicker.value = "";
        formQuantity.value = "";
        formDestination.value = "";
        formReason.value = "";
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    async function handleReview(id, status) {
      try {
        await reviewLogistics(id, status);
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    function statusColor(status) {
      switch (status) {
        case "approved":
          return "rgb(146, 196, 125)";
        case "rejected":
          return "rgb(217, 83, 79)";
        case "completed":
          return "rgba(255, 255, 255, 0.5)";
        default:
          return "rgb(217, 163, 79)";
      }
    }
    function formatDate(iso) {
      const d = new Date(iso);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    }
    onMounted(loadData);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          class: normalizeClass(unref($style).membersToolbar)
        }, [
          createVNode(_sfc_main$1, {
            dark: "",
            onClick: loadData
          }, {
            default: withCtx(() => [..._cache[5] || (_cache[5] = [
              createTextVNode("刷新", -1)
            ])]),
            _: 1
          }),
          unref(canRequest) ? (openBlock(), createBlock(_sfc_main$1, {
            key: 0,
            dark: "",
            onClick: _cache[0] || (_cache[0] = ($event) => showForm.value = !unref(showForm))
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(unref(showForm) ? "取消" : "提交申请"), 1)
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ], 2),
        unref(showForm) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(unref($style).loginContainer)
        }, [
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "物料 Ticker", 2),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(formTicker) ? formTicker.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              type: "text",
              placeholder: "如 RAT, DW",
              style: { "text-transform": "uppercase" }
            }, null, 2), [
              [vModelText, unref(formTicker)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "数量", 2),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(formQuantity) ? formQuantity.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              type: "number",
              min: "1"
            }, null, 2), [
              [vModelText, unref(formQuantity)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "目的地", 2),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(formDestination) ? formDestination.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              type: "text"
            }, null, 2), [
              [vModelText, unref(formDestination)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "理由", 2),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(formReason) ? formReason.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              type: "text"
            }, null, 2), [
              [vModelText, unref(formReason)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).buttonRow)
          }, [
            createVNode(_sfc_main$1, {
              primary: "",
              disabled: !unref(formTicker) || !unref(formQuantity) || !unref(formDestination),
              onClick: handleSubmit
            }, {
              default: withCtx(() => [..._cache[6] || (_cache[6] = [
                createTextVNode("提交", -1)
              ])]),
              _: 1
            }, 8, ["disabled"])
          ], 2)
        ], 2)) : createCommentVNode("", true),
        unref(error) ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(unref($style).errorMessage)
        }, toDisplayString(unref(error)), 3)) : createCommentVNode("", true),
        unref(loading) ? (openBlock(), createElementBlock("div", {
          key: 2,
          class: normalizeClass(unref($style).loadingMessage)
        }, "加载中...", 2)) : (openBlock(), createElementBlock(Fragment, { key: 3 }, [
          unref(requests).length === 0 ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(unref($style).emptyMessage)
          }, "暂无调配申请", 2)) : createCommentVNode("", true),
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(requests), (req) => {
            return openBlock(), createElementBlock("div", {
              key: req.id,
              class: normalizeClass(unref($style).memberRow),
              style: { "flex-direction": "column", "align-items": "stretch" }
            }, [
              createBaseVNode("div", _hoisted_1, [
                createBaseVNode("div", {
                  class: normalizeClass(unref($style).memberInfo)
                }, [
                  createBaseVNode("span", _hoisted_2, toDisplayString(req.materialTicker), 1),
                  createBaseVNode("span", _hoisted_3, "×" + toDisplayString(req.quantity), 1),
                  createBaseVNode("span", _hoisted_4, "→ " + toDisplayString(req.destination), 1),
                  createBaseVNode("span", {
                    class: normalizeClass([unref($style).roleBadge]),
                    style: normalizeStyle({
                      color: statusColor(req.status),
                      backgroundColor: statusColor(req.status).replace("rgb", "rgba").replace(")", ", 0.15)")
                    })
                  }, toDisplayString(unref(LOGISTICS_STATUS_LABELS)[req.status]), 7)
                ], 2),
                createBaseVNode("span", {
                  class: normalizeClass(unref($style).memberJoined)
                }, toDisplayString(req.requester) + " · " + toDisplayString(formatDate(req.createdAt)), 3)
              ]),
              req.reason ? (openBlock(), createElementBlock("div", _hoisted_5, toDisplayString(req.reason), 1)) : createCommentVNode("", true),
              unref(isExecutive) && req.status === "pending" ? (openBlock(), createElementBlock("div", _hoisted_6, [
                createVNode(_sfc_main$1, {
                  success: "",
                  onClick: ($event) => handleReview(req.id, "approved")
                }, {
                  default: withCtx(() => [..._cache[7] || (_cache[7] = [
                    createTextVNode("批准", -1)
                  ])]),
                  _: 2
                }, 1032, ["onClick"]),
                createVNode(_sfc_main$1, {
                  danger: "",
                  onClick: ($event) => handleReview(req.id, "rejected")
                }, {
                  default: withCtx(() => [..._cache[8] || (_cache[8] = [
                    createTextVNode("拒绝", -1)
                  ])]),
                  _: 2
                }, 1032, ["onClick"])
              ])) : createCommentVNode("", true),
              unref(isExecutive) && req.status === "approved" ? (openBlock(), createElementBlock("div", _hoisted_7, [
                createVNode(_sfc_main$1, {
                  dark: "",
                  onClick: ($event) => handleReview(req.id, "completed")
                }, {
                  default: withCtx(() => [..._cache[9] || (_cache[9] = [
                    createTextVNode("标记完成", -1)
                  ])]),
                  _: 2
                }, 1032, ["onClick"])
              ])) : createCommentVNode("", true)
            ], 2);
          }), 128))
        ], 64))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
