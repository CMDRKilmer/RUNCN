import _sfc_main from "./FactionTasks.vue.js";
export {
  _sfc_main as default
};
