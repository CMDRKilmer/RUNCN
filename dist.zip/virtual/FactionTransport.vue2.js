import _sfc_main from "./FactionTransport.vue.js";
export {
  _sfc_main as default
};
