import _sfc_main from "./FactionTreasury.vue.js";
export {
  _sfc_main as default
};
