const fakeRow = "rp-FakeRow__fakeRow___24c063d";
const buttons = "rp-FakeRow__buttons___48d2075";
const style0 = {
  fakeRow,
  buttons
};
export {
  buttons,
  style0 as default,
  fakeRow
};
