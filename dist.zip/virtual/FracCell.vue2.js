import { C } from "./prun-css.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode } from "./runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FracCell",
  props: {
    numerator: {},
    denominator: {}
  },
  setup(__props) {
    const burnClass = computed(() => ({
      [C.Workforces.daysMissing]: __props.numerator < __props.denominator,
      [C.Workforces.daysSupplied]: __props.numerator >= __props.denominator
    }));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("td", {
        class: normalizeClass(_ctx.$style.cell)
      }, [
        createBaseVNode("div", {
          class: normalizeClass([unref(burnClass), _ctx.$style.overlay])
        }, null, 2),
        createBaseVNode("span", null, toDisplayString(_ctx.numerator) + "/" + toDisplayString(_ctx.denominator), 1)
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
