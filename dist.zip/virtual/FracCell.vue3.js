const cell = "rp-FracCell__cell___3cd6e06";
const overlay = "rp-FracCell__overlay___e610c18";
const style0 = {
  cell,
  overlay
};
export {
  cell,
  style0 as default,
  overlay
};
