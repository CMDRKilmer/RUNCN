import _sfc_main from "./GenerateActDialog.vue2.js";
import style0 from "./GenerateActDialog.vue3.js";
import _export_sfc from "./plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const GenerateActDialog = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  GenerateActDialog as default
};
