const notice = "rp-GenerateActDialog__notice___985acb0";
const preview = "rp-GenerateActDialog__preview___5cd2e47";
const style0 = {
  notice,
  preview
};
export {
  style0 as default,
  notice,
  preview
};
