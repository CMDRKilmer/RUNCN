import _sfc_main$1 from "./PrunButton.vue.js";
import GenerateBraRepairActDialog from "./GenerateBraRepairActDialog.vue.js";
import { showTileOverlay } from "./tile-overlay.js";
import { defineComponent, openBlock, createBlock, withCtx, createTextVNode } from "./runtime-core.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GenerateBraRepairActButton",
  props: {
    planetNaturalId: {}
  },
  setup(__props) {
    function onClick(ev) {
      showTileOverlay(ev, GenerateBraRepairActDialog, { planetNaturalId: __props.planetNaturalId });
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1, {
        dark: "",
        onClick
      }, {
        default: withCtx(() => [..._cache[0] || (_cache[0] = [
          createTextVNode("生成维修ACT", -1)
        ])]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default
};
