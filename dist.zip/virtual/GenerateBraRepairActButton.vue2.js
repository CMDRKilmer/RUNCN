import _sfc_main from "./GenerateBraRepairActButton.vue.js";
export {
  _sfc_main as default
};
