const notice = "rp-GenerateBraRepairActDialog__notice___9a1b21a";
const style0 = {
  notice
};
export {
  style0 as default,
  notice
};
