import { C } from "./prun-css.js";
import _sfc_main$2 from "./PrunButton.vue.js";
import SectionHeader from "./SectionHeader.vue.js";
import _sfc_main$1 from "./Active.vue.js";
import SelectInput from "./SelectInput.vue.js";
import _sfc_main$3 from "./Commands.vue.js";
import { calculateHQUpgradeMaterials } from "./hq.js";
import { userData } from "./user-data.js";
import { configurableValue } from "./shared-types.js";
import { showBuffer } from "./buffers.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "./shared.esm-bundler.js";
const packageName = "ZONGBUSHENJI";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GenerateHQUCActDialog",
  props: {
    from: {},
    to: {}
  },
  setup(__props) {
    const exchangeStationMap = {
      AI1: "Antares Station",
      CI1: "Benten Station",
      IC1: "Hortus Station",
      NC1: "Moria Station",
      CI2: "Arclight Station",
      NC2: "Hubur Station"
    };
    const exchanges = Object.keys(exchangeStationMap);
    const exchange = ref(exchanges[0]);
    const warehouseName = computed(() => `${exchangeStationMap[exchange.value]} Warehouse`);
    function onGenerateClick() {
      const materialAmounts = calculateHQUpgradeMaterials(__props.from, __props.to);
      const materials = {};
      for (const { material, amount } of materialAmounts) {
        if (amount > 0) {
          materials[material.ticker] = amount;
        }
      }
      if (Object.keys(materials).length === 0) {
        return;
      }
      const groupName = "HQ Upgrade";
      const name = packageName;
      const pkg = {
        global: { name },
        groups: [
          {
            type: "Manual",
            name: groupName,
            materials
          }
        ],
        actions: [
          {
            type: "CX Buy",
            name: "CX Buy",
            group: groupName,
            exchange: exchange.value,
            buyPartial: false,
            allowUnfilled: false,
            useCXInv: true
          },
          {
            type: "MTRA",
            name: "Transfer to HQ",
            group: groupName,
            origin: warehouseName.value,
            dest: configurableValue
          }
        ]
      };
      const existing = userData.actionPackages.find((x) => x.global.name === name);
      if (existing) {
        const index = userData.actionPackages.indexOf(existing);
        userData.actionPackages[index] = pkg;
      } else {
        userData.actionPackages.push(pkg);
      }
      showBuffer(`XIT ACT_${name}`);
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).DraftConditionEditor.form)
      }, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[1] || (_cache[1] = [
            createTextVNode("生成升级 ACT 包", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$1, { label: "升级范围" }, {
            default: withCtx(() => [
              createBaseVNode("span", null, toDisplayString(_ctx.from) + " → " + toDisplayString(_ctx.to), 1)
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, { label: "交易所" }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(exchange),
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(exchange) ? exchange.value = $event : null),
                options: unref(exchanges)
              }, null, 8, ["modelValue", "options"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, { label: "仓库" }, {
            default: withCtx(() => [
              createBaseVNode("span", null, toDisplayString(unref(warehouseName)), 1)
            ]),
            _: 1
          }),
          createVNode(_sfc_main$3, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$2, {
                primary: "",
                onClick: onGenerateClick
              }, {
                default: withCtx(() => [..._cache[2] || (_cache[2] = [
                  createTextVNode("生成", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ])
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
