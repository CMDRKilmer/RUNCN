import { C } from "./prun-css.js";
import _sfc_main$3 from "./PrunButton.vue.js";
import SectionHeader from "./SectionHeader.vue.js";
import _sfc_main$1 from "./Active.vue.js";
import _sfc_main$2 from "./RadioItem.vue.js";
import SelectInput from "./SelectInput.vue.js";
import _sfc_main$4 from "./Commands.vue.js";
import { shipsStore } from "./ships.js";
import { storagesStore } from "./storage.js";
import { userData } from "./user-data.js";
import { configurableValue } from "./shared-types.js";
import { showBuffer } from "./buffers.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
const packageName = "FEICHUANWEIXIU";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GenerateRepairActDialog",
  props: {
    registration: {}
  },
  setup(__props) {
    const ship = computed(() => shipsStore.getByRegistration(__props.registration));
    const exchangeStationMap = {
      AI1: "Antares Station",
      CI1: "Benten Station",
      IC1: "Hortus Station",
      NC1: "Moria Station",
      CI2: "Arclight Station",
      NC2: "Hubur Station"
    };
    const exchanges = Object.keys(exchangeStationMap);
    const exchange = ref(exchanges[0]);
    const useShipInv = ref(true);
    const warehouseName = computed(() => `${exchangeStationMap[exchange.value]} Warehouse`);
    function onGenerateClick() {
      if (!ship.value) {
        return;
      }
      const shipInventory = {};
      if (useShipInv.value) {
        const shipStore = storagesStore.getById(ship.value.idShipStore);
        if (shipStore) {
          for (const item of shipStore.items) {
            if (item.quantity) {
              shipInventory[item.quantity.material.ticker] = item.quantity.amount;
            }
          }
        }
      }
      const materials = {};
      for (const { material, amount } of ship.value.repairMaterials) {
        const inShip = shipInventory[material.ticker] ?? 0;
        const need = Math.max(0, amount - inShip);
        if (need > 0) {
          materials[material.ticker] = need;
        }
      }
      const groupName = "Repair";
      const name = packageName;
      const pkg = {
        global: { name },
        groups: [
          {
            type: "Manual",
            name: groupName,
            materials
          }
        ],
        actions: [
          {
            type: "CX Buy",
            name: "CX Buy",
            group: groupName,
            exchange: exchange.value,
            buyPartial: false,
            allowUnfilled: false,
            useCXInv: true
          },
          {
            type: "MTRA",
            name: "Transfer to Ship",
            group: groupName,
            origin: warehouseName.value,
            dest: configurableValue
          }
        ]
      };
      const existing = userData.actionPackages.find((x) => x.global.name === name);
      if (existing) {
        const index = userData.actionPackages.indexOf(existing);
        userData.actionPackages[index] = pkg;
      } else {
        userData.actionPackages.push(pkg);
      }
      showBuffer(`XIT ACT_${name.split(" ").join("_")}`);
    }
    return (_ctx, _cache) => {
      return !unref(ship) ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).DraftConditionEditor.form)
      }, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[2] || (_cache[2] = [
            createTextVNode("生成维修 ACT 包", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.notice)
        }, "未找到飞船数据。", 2)
      ], 2)) : (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).DraftConditionEditor.form)
      }, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[3] || (_cache[3] = [
            createTextVNode("生成维修 ACT 包", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$1, { label: "飞船" }, {
            default: withCtx(() => [
              createBaseVNode("span", null, toDisplayString(unref(ship).name), 1)
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, { label: "交易所" }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(exchange),
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(exchange) ? exchange.value = $event : null),
                options: unref(exchanges)
              }, null, 8, ["modelValue", "options"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, { label: "仓库" }, {
            default: withCtx(() => [
              createBaseVNode("span", null, toDisplayString(unref(warehouseName)), 1)
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, {
            label: "扣除飞船库存",
            tooltip: "扣除飞船货舱中已有的材料后再计算采购量。"
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$2, {
                modelValue: unref(useShipInv),
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(useShipInv) ? useShipInv.value = $event : null)
              }, {
                default: withCtx(() => [..._cache[4] || (_cache[4] = [
                  createTextVNode("扣除飞船库存", -1)
                ])]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$4, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$3, {
                primary: "",
                onClick: onGenerateClick
              }, {
                default: withCtx(() => [..._cache[5] || (_cache[5] = [
                  createTextVNode("生成", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ])
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
