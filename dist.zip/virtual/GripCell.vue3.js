const gripCell = "rp-GripCell__gripCell___ce46b37";
const grip = "rp-GripCell__grip___75de9f1";
const style0 = {
  gripCell,
  grip
};
export {
  style0 as default,
  grip,
  gripCell
};
