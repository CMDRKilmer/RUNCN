import fa from "./font-awesome.module.css.js";
import { defineComponent, openBlock, createElementBlock } from "./runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GripChar",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("span", {
        class: normalizeClass(unref(fa).solid)
      }, toDisplayString(""), 2);
    };
  }
});
export {
  _sfc_main as default
};
