const dragHeaderCell = "rp-GripHeaderCell__dragHeaderCell___20faa2b";
const style0 = {
  dragHeaderCell
};
export {
  style0 as default,
  dragHeaderCell
};
