import xit from "./xit-registry.js";
import _sfc_main from "./HEALTH.vue.js";
xit.add({
  command: "HEALTH",
  name: "数据健康",
  description: "显示已收集数据的统计信息。",
  component: () => _sfc_main
});
