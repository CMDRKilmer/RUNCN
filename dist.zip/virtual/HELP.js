import xit from "./xit-registry.js";
import _sfc_main from "./HELP.vue.js";
xit.add({
  command: "HELP",
  name: "帮助",
  description: "开始使用 Refined PrUn 的有用信息。",
  optionalParameters: "操作",
  component: () => _sfc_main
});
