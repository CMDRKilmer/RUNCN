import PrunLink from "./PrunLink.vue.js";
import { defineComponent, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode } from "./runtime-core.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "HELP",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("table", null, [
        _cache[6] || (_cache[6] = createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            createBaseVNode("th", null, "我想要..."),
            createBaseVNode("th", null, "命令")
          ])
        ], -1)),
        createBaseVNode("tbody", null, [
          createBaseVNode("tr", null, [
            _cache[0] || (_cache[0] = createBaseVNode("td", null, "更改 Refined PrUn 设置。", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT SET" })
            ])
          ]),
          createBaseVNode("tr", null, [
            _cache[1] || (_cache[1] = createBaseVNode("td", null, "将功能集切换为基础/完整模式。", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT SET FEAT" })
            ])
          ]),
          createBaseVNode("tr", null, [
            _cache[2] || (_cache[2] = createBaseVNode("td", null, "禁用某个 Refined PrUn 功能。", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT SET FEAT" })
            ])
          ]),
          createBaseVNode("tr", null, [
            _cache[3] || (_cache[3] = createBaseVNode("td", null, "查看可用的 XIT 命令。", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT CMDS" })
            ])
          ]),
          createBaseVNode("tr", null, [
            _cache[4] || (_cache[4] = createBaseVNode("td", null, "导入 PMMG 设置。", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT SET PMMG" })
            ])
          ]),
          createBaseVNode("tr", null, [
            _cache[5] || (_cache[5] = createBaseVNode("td", null, "获取随机柯基犬 GIF。", -1)),
            createBaseVNode("td", null, [
              createVNode(PrunLink, { command: "XIT GIF CORGI" })
            ])
          ])
        ])
      ]);
    };
  }
});
export {
  _sfc_main as default
};
