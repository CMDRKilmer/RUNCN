import xit from "./xit-registry.js";
import HQUC from "./HQUC.vue.js";
xit.add({
  command: ["HQUC"],
  name: "总部升级计算器",
  description: "总部升级计算器。",
  component: () => HQUC
});
