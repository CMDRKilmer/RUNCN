import { subscribe } from "./subscribe-async-generator.js";
import { $$ } from "./select-dom.js";
import { C } from "./prun-css.js";
import { createFragmentApp } from "./vue-fragment-app.js";
import tiles from "./tiles.js";
import features from "./feature-registry.js";
import css from "./css-utils.module.css.js";
import { sitesStore } from "./sites.js";
import { computed, createVNode } from "./runtime-core.esm-bundler.js";
function onTileReady(tile) {
  const naturalId = tile.parameter;
  const totals = computed(() => {
    const totals2 = /* @__PURE__ */ new Map();
    const buildings = sitesStore.getByPlanetNaturalId(naturalId)?.platforms ?? [];
    for (const building of buildings) {
      const ticker = building.module.reactorTicker;
      totals2.set(ticker, (totals2.get(ticker) ?? 0) + 1);
    }
    return totals2;
  });
  subscribe($$(tile.anchor, C.BuildingIcon.tickerContainer), (tickerContainer) => {
    const ticker = tickerContainer.textContent;
    if (!ticker) {
      return;
    }
    const count = computed(() => totals.value.get(ticker) ?? 0);
    const isVisible = computed(() => count.value > 0);
    const hiddenClass = computed(() => isVisible.value ? void 0 : css.hidden);
    createFragmentApp(() => createVNode("div", {
      "class": [C.MaterialIcon.indicatorContainer, hiddenClass.value]
    }, [createVNode("div", {
      "class": [C.MaterialIcon.indicator, C.MaterialIcon.neutral, C.MaterialIcon.typeVerySmall]
    }, [totals.value.get(ticker)])])).appendTo(tickerContainer);
  });
}
function init() {
  tiles.observe("BBC", onTileReady);
}
features.add(import.meta.url, init, "BBC：在建筑图标上添加建筑数量标签。");
