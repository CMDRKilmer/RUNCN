import { compareMaterials } from "./sort-materials.js";
import { configurableValue } from "./shared-types.js";
import { exchangesStore } from "./exchanges.js";
import { materialsStore } from "./materials.js";
import { stationsStore } from "./stations.js";
function defaultCartName() {
  return "Shopping Cart";
}
function normalizeCartName(name) {
  const trimmed = name?.trim();
  return trimmed && trimmed.length > 0 ? trimmed : defaultCartName();
}
function buildActionPackage(cart) {
  const materials = toMaterialRecord(cart.items);
  const exchange = cart.exchange?.trim();
  if (!exchange || Object.keys(materials).length === 0) {
    return void 0;
  }
  const groupName = "Cart";
  const name = normalizeCartName(cart.name);
  const pkg = {
    global: { name },
    groups: [
      {
        type: "Manual",
        name: groupName,
        materials
      }
    ],
    actions: [
      {
        type: "CX Buy",
        name: "BuyItems",
        group: groupName,
        exchange,
        priceLimits: {},
        buyPartial: false,
        allowUnfilled: false,
        useCXInv: true
      },
      {
        type: "MTRA",
        name: "TransferAction",
        group: groupName,
        origin: getWarehouseName(exchange),
        dest: configurableValue
      }
    ]
  };
  return pkg;
}
function parseCartImport(source) {
  const state = {
    materials: /* @__PURE__ */ new Map()
  };
  visitSource(source, state);
  const items = normalizeCartItems(
    Array.from(state.materials, ([ticker, amount]) => ({
      ticker,
      amount
    }))
  );
  if (items.length === 0) {
    throw new Error("No cart items found in JSON.");
  }
  return {
    name: state.name ? normalizeCartName(state.name) : void 0,
    exchange: state.exchange,
    items
  };
}
function normalizeCartItems(items) {
  const merged = /* @__PURE__ */ new Map();
  for (const item of items) {
    const ticker = normalizeTicker(item.ticker);
    const amount = normalizeAmount(item.amount);
    if (!ticker || !amount) {
      continue;
    }
    merged.set(ticker, (merged.get(ticker) ?? 0) + amount);
  }
  return Array.from(merged, ([ticker, amount]) => ({ ticker, amount })).sort((a, b) => {
    const byMaterial = compareMaterials(
      materialsStore.getByTicker(a.ticker),
      materialsStore.getByTicker(b.ticker)
    );
    return byMaterial || a.ticker.localeCompare(b.ticker);
  });
}
function getWarehouseName(exchangeCode) {
  const stationName = getStationName(exchangeCode);
  return `${stationName ?? exchangeCode ?? "Station"} Warehouse`;
}
function getStationName(exchangeCode) {
  const naturalId = exchangesStore.getNaturalIdFromCode(exchangeCode);
  return stationsStore.getByNaturalId(naturalId)?.name;
}
function getExchangeOptions() {
  return (exchangesStore.all.value ?? []).slice().sort((a, b) => a.code.localeCompare(b.code)).map((exchange) => {
    const stationName = getStationName(exchange.code) ?? exchange.name;
    return {
      label: `${exchange.code} - ${stationName}`,
      value: exchange.code
    };
  });
}
function visitSource(source, state) {
  if (Array.isArray(source)) {
    for (const entry of source) {
      visitSource(entry, state);
    }
    return;
  }
  if (!source || typeof source !== "object") {
    return;
  }
  const record = source;
  if (!state.name) {
    const globalName = asString(record.global?.name);
    if (globalName) {
      state.name = globalName;
    }
  }
  if (!state.exchange) {
    const directExchange = asString(record.exchange);
    if (directExchange) {
      state.exchange = directExchange;
    }
  }
  mergeMaterialRecord(record, state.materials);
  mergeMaterialRecord(record.materials, state.materials);
  if (Array.isArray(record.groups)) {
    for (const group of record.groups) {
      if (!group || typeof group !== "object") {
        continue;
      }
      mergeMaterialRecord(group.materials, state.materials);
    }
  }
  if (Array.isArray(record.actions) && !state.exchange) {
    state.exchange = inferExchangeFromActions(record.actions);
  }
  const ticker = normalizeTicker(asString(record.ticker));
  const amount = normalizeAmount(record.amount);
  if (ticker && amount) {
    state.materials.set(ticker, (state.materials.get(ticker) ?? 0) + amount);
  }
}
function mergeMaterialRecord(source, target) {
  if (!source || typeof source !== "object" || Array.isArray(source)) {
    return;
  }
  for (const [ticker, amount] of Object.entries(source)) {
    const normalizedTicker = normalizeTicker(ticker);
    const normalizedAmount = normalizeAmount(amount);
    if (!normalizedTicker || !normalizedAmount) {
      continue;
    }
    target.set(normalizedTicker, (target.get(normalizedTicker) ?? 0) + normalizedAmount);
  }
}
function inferExchangeFromActions(actions) {
  for (const action of actions) {
    if (!action || typeof action !== "object") {
      continue;
    }
    const record = action;
    if (record.type === "CX Buy") {
      const exchange = asString(record.exchange);
      if (exchange) {
        return exchange;
      }
    }
  }
  for (const action of actions) {
    if (!action || typeof action !== "object") {
      continue;
    }
    const record = action;
    if (record.type !== "MTRA") {
      continue;
    }
    const exchange = inferExchangeFromOrigin(asString(record.origin));
    if (exchange) {
      return exchange;
    }
  }
  return void 0;
}
function inferExchangeFromOrigin(origin) {
  if (!origin) {
    return void 0;
  }
  const stationName = origin.endsWith(" Warehouse") ? origin.substring(0, origin.length - " Warehouse".length).trim() : origin.trim();
  const naturalId = stationsStore.getNaturalIdFromName(stationName);
  return naturalId ? exchangesStore.getByNaturalId(naturalId)?.code : void 0;
}
function toMaterialRecord(items) {
  const materials = {};
  for (const item of items) {
    const ticker = normalizeTicker(item.ticker);
    const amount = normalizeAmount(item.amount);
    if (!ticker || !amount) {
      continue;
    }
    materials[ticker] = (materials[ticker] ?? 0) + amount;
  }
  return materials;
}
function normalizeTicker(ticker) {
  const normalized = ticker?.trim().toUpperCase();
  if (!normalized || !/^[A-Z0-9-]+$/.test(normalized)) {
    return void 0;
  }
  return normalized;
}
function normalizeAmount(amount) {
  const numeric = Number(amount);
  if (!Number.isFinite(numeric) || numeric <= 0) {
    return void 0;
  }
  return Math.ceil(numeric);
}
function asString(value) {
  return typeof value === "string" ? value : void 0;
}
export {
  buildActionPackage,
  defaultCartName,
  getExchangeOptions,
  getStationName,
  getWarehouseName,
  normalizeCartItems,
  normalizeCartName,
  parseCartImport
};
