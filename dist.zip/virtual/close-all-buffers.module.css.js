const closeAllBtn = "rp-close-all-buffers__closeAllBtn___ad3f6a6";
const $style = {
  closeAllBtn
};
export {
  closeAllBtn,
  $style as default
};
