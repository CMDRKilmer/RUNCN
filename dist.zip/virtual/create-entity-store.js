import { onApiMessage } from "./api-messages.js";
import { PrefixStore } from "./prefix-store.js";
import { shallowReactive, shallowRef, ref, triggerRef } from "./reactivity.esm-bundler.js";
import { computed } from "./runtime-core.esm-bundler.js";
function createEntityStore(options) {
  const selectId = options?.selectId ?? ((model) => model.id);
  const transformId = options?.transformId ?? ((s) => s.toUpperCase());
  let entities = shallowReactive({});
  const prefixStoreRef = shallowRef(new PrefixStore());
  const fetched = ref(false);
  function rebuildPrefixStore() {
    const prefixStore = prefixStoreRef.value;
    prefixStore.clear();
    for (const key in entities) {
      prefixStore.insert(transformId(key), entities[key]);
    }
    triggerRef(prefixStoreRef);
  }
  if (!options?.preserveOnConnectionOpen) {
    onApiMessage({
      CLIENT_CONNECTION_OPENED() {
        fetched.value = false;
        entities = shallowReactive({});
        prefixStoreRef.value = new PrefixStore();
      }
    });
  }
  return {
    state: {
      fetched,
      entities: computed(() => {
        return fetched.value ? entities : void 0;
      }),
      all: computed(() => fetched.value ? Object.values(entities) : void 0),
      getById: (id) => {
        if (!id || !fetched.value) {
          return void 0;
        }
        const exact = entities[id];
        if (exact !== void 0) {
          return exact;
        }
        return prefixStoreRef.value.findOne(transformId(id));
      },
      getAllById: (id) => {
        if (!id || !fetched.value) {
          return void 0;
        }
        return prefixStoreRef.value.findAll(transformId(id));
      }
    },
    setAll(items) {
      for (const key in entities) {
        delete entities[key];
      }
      for (const item of items) {
        entities[selectId(item)] = item;
      }
      rebuildPrefixStore();
    },
    setOne(item) {
      const id = selectId(item);
      entities[id] = item;
      prefixStoreRef.value.setOne(transformId(id), item);
      triggerRef(prefixStoreRef);
    },
    setMany(items) {
      const prefixStore = prefixStoreRef.value;
      for (const item of items) {
        const id = selectId(item);
        entities[id] = item;
        prefixStore.setOne(transformId(id), item);
      }
      triggerRef(prefixStoreRef);
    },
    addOne(item) {
      const id = selectId(item);
      if (!entities[id]) {
        entities[id] = item;
        prefixStoreRef.value.insert(transformId(id), item);
        triggerRef(prefixStoreRef);
      }
    },
    updateOne(item) {
      const id = selectId(item);
      if (entities[id]) {
        entities[id] = {
          ...entities[id],
          ...item
        };
        prefixStoreRef.value.setOne(transformId(id), entities[id]);
        triggerRef(prefixStoreRef);
      }
    },
    removeOne(id) {
      delete entities[id];
      prefixStoreRef.value.remove(transformId(id));
      triggerRef(prefixStoreRef);
    },
    setFetched() {
      fetched.value = true;
    }
  };
}
export {
  createEntityStore
};
