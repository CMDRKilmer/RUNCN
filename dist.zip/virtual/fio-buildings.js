import { shallowReactive } from "./reactivity.esm-bundler.js";
const fioBuildingsStore = shallowReactive({
  buildings: void 0,
  loading: false,
  error: false
});
let fetchStarted = false;
const FIO_URL = "https://rest.fnar.net/building/allbuildings";
async function loadFioBuildings() {
  if (fetchStarted) {
    return;
  }
  fetchStarted = true;
  fioBuildingsStore.loading = true;
  fioBuildingsStore.error = false;
  try {
    const response = await fetch(FIO_URL);
    if (!response.ok) {
      fioBuildingsStore.error = true;
      return;
    }
    fioBuildingsStore.buildings = await response.json();
  } catch {
    fioBuildingsStore.error = true;
  } finally {
    fioBuildingsStore.loading = false;
  }
}
export {
  fioBuildingsStore,
  loadFioBuildings
};
