import { applyCssRule } from "./refined-prun-css.js";
import features from "./feature-registry.js";
import { PrunI18N } from "./i18n.js";
import $style from "./flt-flight-status-icons.module.css.js";
function init() {
  const replacements = [
    {
      key: "ships.status.stationary",
      icon: "⦁"
    },
    {
      key: "ShipStatus.takeoff",
      icon: "↑"
    },
    {
      key: "ShipStatus.departure",
      icon: "↗"
    },
    {
      key: "ShipStatus.transit",
      icon: "⟶"
    },
    {
      key: "ShipStatus.charge",
      icon: "±"
    },
    {
      key: "ShipStatus.jump",
      icon: "➾"
    },
    {
      key: "ShipStatus.float",
      icon: "↑"
    },
    {
      key: "ShipStatus.approach",
      icon: "↘"
    },
    {
      key: "ShipStatus.landing",
      icon: "↓"
    },
    {
      key: "ShipStatus.lock",
      icon: "⟴"
    },
    {
      key: "ShipStatus.decay",
      icon: "⟴"
    },
    {
      key: "ShipStatus.jumpgateway",
      icon: "⟴"
    }
  ];
  for (const { key, icon } of replacements) {
    PrunI18N[key] = [
      {
        type: 0,
        value: icon
      }
    ];
  }
  applyCssRule(["FLT", "FLTS", "FLTP"], `td:nth-child(4)`, $style.status);
}
features.add(import.meta.url, init, "FLT：将飞行状态文本替换为箭头图标。");
