import { subscribe } from "./subscribe-async-generator.js";
import { $$ } from "./select-dom.js";
import { createFragmentApp } from "./vue-fragment-app.js";
import tiles from "./tiles.js";
import features from "./feature-registry.js";
import { refPrunId } from "./attributes.js";
import _sfc_main from "./QuickRefuelButton.vue.js";
import { reactive } from "./reactivity.esm-bundler.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, "tr"), (row) => onRowReady(row, tile));
}
function onRowReady(row, tile) {
  const id = refPrunId(row);
  if (!id.value) {
    return;
  }
  const commandsCell = row.lastElementChild;
  if (!(commandsCell instanceof HTMLElement) || commandsCell.dataset.rprunQuickRefuel === "1") {
    return;
  }
  const buttonProps = reactive({
    dark: true,
    direct: true,
    id,
    inline: true,
    label: "加油",
    tile
  });
  const lastButton = commandsCell.querySelector("button:last-of-type");
  if (lastButton instanceof HTMLElement) {
    createFragmentApp(_sfc_main, buttonProps).after(lastButton);
  } else {
    createFragmentApp(_sfc_main, buttonProps).appendTo(commandsCell);
  }
  commandsCell.dataset.rprunQuickRefuel = "1";
}
function init() {
  tiles.observe(["FLT", "FLTS", "FLTP"], onTileReady);
}
features.add(import.meta.url, init, "FLT：在卸货按钮右侧添加加油按钮。");
