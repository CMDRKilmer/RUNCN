import { subscribe } from "./subscribe-async-generator.js";
import { $$ } from "./select-dom.js";
import { C } from "./prun-css.js";
import tiles from "./tiles.js";
import features from "./feature-registry.js";
import { extractPlanetName } from "./util.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.Link.link), (link) => {
    if (link.textContent) {
      link.textContent = extractPlanetName(link.textContent);
    }
  });
}
function init() {
  tiles.observe(["FLT", "FLTS", "FLTP"], onTileReady);
}
features.add(import.meta.url, init, 'FLT：缩短"位置"和"目的地"中的地址。');
