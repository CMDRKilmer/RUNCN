import { subscribe } from "./subscribe-async-generator.js";
import { _$, $$ } from "./select-dom.js";
import { C } from "./prun-css.js";
import { createFragmentApp } from "./vue-fragment-app.js";
import tiles from "./tiles.js";
import features from "./feature-registry.js";
import { clickElement } from "./util.js";
import { refAnimationFrame } from "./reactive-dom.js";
import _sfc_main from "./PrunButton.vue.js";
import { createVNode, createTextVNode } from "./runtime-core.esm-bundler.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, "rc-slider"), async () => {
    if (_$(tile.anchor, C.Button.primary)) return;
    const btn = _$(tile.anchor, C.Button.btn);
    if (!btn) return;
    const maxSliders = async () => {
      const sliders = Array.from(tile.anchor.getElementsByClassName("rc-slider"));
      for (const slider of sliders) {
        if (slider.classList.contains("rc-slider-disabled")) continue;
        const mark = slider.getElementsByClassName("rc-slider-mark")[0];
        if (!mark?.lastElementChild) continue;
        await clickElement(mark.lastElementChild);
      }
    };
    const minSliders = async () => {
      const sliders = Array.from(tile.anchor.getElementsByClassName("rc-slider"));
      for (const slider of sliders) {
        if (slider.classList.contains("rc-slider-disabled")) continue;
        const mark = slider.getElementsByClassName("rc-slider-mark")[0];
        if (!mark?.firstElementChild) continue;
        await clickElement(mark.firstElementChild);
      }
    };
    const allSliders = tile.anchor.getElementsByClassName("rc-slider");
    const disabledSliders = tile.anchor.getElementsByClassName("rc-slider-disabled");
    const disabled = refAnimationFrame(tile.anchor, () => allSliders.length > 0 && allSliders.length === disabledSliders.length);
    createFragmentApp(() => createVNode(_sfc_main, {
      "primary": true,
      "disabled": disabled.value,
      "onClick": maxSliders
    }, {
      default: () => [createTextVNode("ALL")]
    })).before(btn);
    createFragmentApp(() => createVNode(_sfc_main, {
      "primary": true,
      "disabled": disabled.value,
      "onClick": minSliders
    }, {
      default: () => [createTextVNode("NONE")]
    })).before(btn);
  });
}
function init() {
  tiles.observe("HQ", onTileReady);
}
features.add(import.meta.url, init, "HQ：在总部升级分配面板中添加 NONE/ALL 批量控制按钮。");
